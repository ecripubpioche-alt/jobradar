// Génère les icônes launcher Android depuis scripts/icon-source.svg
import { mkdir } from "node:fs/promises";
import sharp from "sharp";
const SRC = "scripts/icon-source.svg";
const RES = "android/app/src/main/res";
const sizes = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
for (const [d, s] of Object.entries(sizes)) {
  const dir = `${RES}/mipmap-${d}`;
  await mkdir(dir, { recursive: true });
  const icon = await sharp(SRC, { density: 512 }).resize(s, s).png().toBuffer();
  await sharp(icon).toFile(`${dir}/ic_launcher.png`);
  await sharp(icon).toFile(`${dir}/ic_launcher_round.png`);
  const fg = Math.round(s * 2.25), inner = Math.round(fg * 0.62);
  const logo = await sharp(SRC, { density: 512 }).resize(inner, inner).png().toBuffer();
  await sharp({ create: { width: fg, height: fg, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
    .composite([{ input: logo, top: Math.round((fg - inner) / 2), left: Math.round((fg - inner) / 2) }])
    .png().toFile(`${dir}/ic_launcher_foreground.png`);
  console.log("✓", d);
}
