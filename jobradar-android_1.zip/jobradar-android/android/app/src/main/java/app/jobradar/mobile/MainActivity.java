package app.jobradar.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
