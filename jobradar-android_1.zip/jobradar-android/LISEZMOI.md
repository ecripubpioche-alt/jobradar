# JobRadar — APK Android

JobRadar est une application web (Next.js + PostgreSQL). L'APK est une coque Android (Capacitor)
qui affiche votre site déployé : **le site doit donc être hébergé en HTTPS** (avec sa base PostgreSQL
et la variable DATABASE_URL) avant de produire l'APK.

## Obtenir l'APK (sans installer Android Studio)
1. Déployez l'application web (Vercel, Railway, Render…) et notez l'URL HTTPS.
2. Créez un dépôt GitHub, poussez ce dossier.
3. Onglet **Actions → Build APK JobRadar → Run workflow**, saisissez l'URL du site.
4. Au bout de ~5 min, téléchargez `JobRadar-apk` (contient `app-debug.apk`).
5. Sur le téléphone : autorisez « sources inconnues » et installez l'APK.

## Compiler en local
Prérequis : Node 20, JDK 17+, Android SDK.
```
npm install
# éditer server.url dans capacitor.config.json
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK : `android/app/build/outputs/apk/debug/app-debug.apk`

## Play Store
Pour publier, il faut un AAB signé avec votre propre keystore (`./gradlew bundleRelease`),
voir PLAY_STORE.md du projet web.
